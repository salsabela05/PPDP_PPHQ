<div class="table-responsive">
    <h5>Rincian Biaya - Santri Tahfidz</h5>
    <table class="table table-bordered">
        <thead class="table-success">
            <tr>
                <th>No</th>
                <th>Uraian</th>
                <th>Jumlah (Rp)</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Infaq Pembangunan</td>
                <td>1.000.000</td>
                <td>Awal Masuk</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Jas Almamater</td>
                <td>180.000</td>
                <td>Awal Masuk</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Sewa Lemari</td>
                <td>500.000</td>
                <td>Awal Masuk</td>
            </tr>
            <tr>
                <td>4</td>
                <td>Kasur & Bantal</td>
                <td>350.000</td>
                <td>Awal Masuk</td>
            </tr>
             <tr>
                <td>5</td>
                <td>Seragam</td>
                <td>400.000</td>
                <td>Awal Masuk</td>
            </tr>
             <tr>
                <td>6</td>
                <td>Syahriyah (Uang Makan)</td>
                <td>400.000</td>
                <td>Setiap Bulan</td>
            </tr>
            <tr>
                <th colspan="2">Total</th>
                <th>2.830.000</th>
                <th></th>
            </tr>
        </tbody>
    </table>
    <tr>
        <p><b>SETELAH MELAKUKAN PEMBAYARAN, HARAP SEGERA MENGUNGGAH BUKTI PEMBAYARAN MELALUI HALAMAN YANG TELAH DISEDIAKAN UNTUK MEMPERCEPAT PROSES VERIFIKASI</b></p>
     </tr>
</div>

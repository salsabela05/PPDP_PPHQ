
<?php $__env->startSection('konten'); ?>

<div class="container">
    <h4>Daftar Santri Diterima</h4>
    <table class="table table-bordered">
        <tr>
            <th>Nama</th>
            <th>Jenjang</th>
            <th>Input Hasil Seleksi</th>
        </tr>
        <?php $__currentLoopData = $santriDiterima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($santri->nama ?? 'Tidak ada nama'); ?></td>
            <td><?php echo e($santri->jenjang ?? '-'); ?></td>
            <td>
                <form action="<?php echo e(route('ketua-tpa.input-hasil', $santri->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <textarea name="hasil_seleksi_tpa" rows="2" class="form-control"><?php echo e($santri->hasil_seleksi_tpa); ?></textarea>
                    <button type="submit" class="btn btn-sm btn-primary mt-1">Simpan</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/ketua_tpa/santri_diterima.blade.php ENDPATH**/ ?>
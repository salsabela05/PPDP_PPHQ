<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Pembayaran</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #f0f0f0; }
        .ttd {
            margin-top: 40px;
            width: 100%;
        }
        .ttd td {
            border: none;
            text-align: right;
            padding-right: 50px;
        }
    </style>
</head>
<body onload="window.print()">
    <h3 style="text-align: center;">Laporan Pembayaran Calon Santri</h3>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Santri</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($p->formulir->nama ?? '-'); ?></td>
                    <td><?php echo e($p->keterangan); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d-m-Y')); ?></td>
                    <td><?php echo e($p->status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table class="ttd">
        <tr>
            <td>Metro, <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?></td>
        </tr>
        <tr><td style="height: 60px;"></td></tr>
        <tr>
            <td>Pondok Pesantren Hidayatul Qur'an</td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/laporan_pembayaran.blade.php ENDPATH**/ ?>
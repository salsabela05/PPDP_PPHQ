

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Input Hasil Seleksi</h3>
    <?php if($santri->isEmpty()): ?>
        <p>Tidak ada santri yang siap diseleksi.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Jenjang</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->jenjang); ?></td>
                    <td>
                        <form action="<?php echo e(route('seleksi.simpan')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="santri_id" value="<?php echo e($s->id); ?>">
                            <select name="hasil_seleksi" class="form-control">
                                <option value="lulus">Lulus</option>
                                <option value="tidak_lulus">Tidak Lulus</option>
                            </select>
                            <button type="submit" class="btn btn-success btn-sm mt-1">Simpan</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/ketua/seleksi.blade.php ENDPATH**/ ?>
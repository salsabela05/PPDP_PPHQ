
<?php $__env->startSection("konten"); ?>

<div class="d-flex mb-3">
    
<h3>Laporan Data Santri</h3>
<div class="ml-auto">
    <a href="/app/laporan/cetak" class="btn btn-primary">cetak laporan</a>
    <a href="/app/laporan/export/pdf" class="btn btn-danger">Export PDF</a>
</div>
</div>

<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <thead style="background-color: #0d6efd; color: white; text-align: center;">
                <tr>
                    <th>No</th>
                    <th>Nama Lengkap</th>
                    <th>NIK</th>
                    <th>Tempat, Tanggal Lahir</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Nama Wali</th>
                    <th>Tahun Masuk</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->formulir->nama); ?></td>
                        <td><?php echo e($p->formulir->nik); ?></td>
                        <td><?php echo e($p->formulir->tempat_lahir); ?></td>
                        <td><?php echo e($p->formulir->jenis_kelamin); ?></td>
                        <td><?php echo e($p->formulir->alamat); ?></td>
                        <td><?php echo e($p->formulir->nama_wali); ?></td>
                        <td><?php echo e(date('Y', strtotime($p->formulir->created_at))); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app/_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/laporan.blade.php ENDPATH**/ ?>
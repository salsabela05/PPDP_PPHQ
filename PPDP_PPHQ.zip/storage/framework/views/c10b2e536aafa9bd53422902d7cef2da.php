

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4 class="mb-3">Daftar Santri Diterima</h4>

    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Nama</th>
                    <th>Jenjang</th>
                    <th>Input Hasil Seleksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $santriDiterima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($santri->nama); ?></td>
                    <td><?php echo e($santri->jenjang); ?></td>
                    <td>
                        <form action="<?php echo e(route('ketua-tpa.input-hasil', $santri->id)); ?>" method="POST" class="d-flex flex-column gap-2">
                            <?php echo csrf_field(); ?>
                            <textarea name="hasil_seleksi_tpa" rows="2" class="form-control" required><?php echo e(old('hasil_seleksi_tpa', $santri->hasil_seleksi_tpa)); ?></textarea>
                            <button type="submit" class="btn btn-success btn-sm">Simpan</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Belum ada santri yang diterima.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/ketua_tpa/index.blade.php ENDPATH**/ ?>
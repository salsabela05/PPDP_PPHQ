
<?php $__env->startSection("konten"); ?>

<div class="card">
    <div class="card-body">

        <h3 class="mt-4">Riwayat Pembayaran</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>calon santri</th>
                    <th>Keterangan</th>
                    <th>Bukti</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->formulir->nama); ?></td>
                        <td><?php echo e($p->keterangan); ?></td>
                        <td><a href="<?php echo e(asset('storage/' . $p->bukti)); ?>" target="_blank">Lihat Bukti</a></td>
                        <td>
                            <?php echo e($p->status); ?>

                            <?php if($p->status_info): ?>
                                <br> <small><?php echo e($p->status_info); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($p->id); ?>">
                                Tolak
                            </button>
                            <form action="/app/daftar-pembayaran/konfirmasi/<?php echo e($p->id); ?>" onclick="return confirm('apakah anda yakin ingin konfirmasi pembayaran?')" method="post">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-primary">
                                    konfirmasi 
                                </button>
                            </form>
                                <?php if($p->status == 'dikonfirmasi' && $p->kwitansi): ?>
                                    <a href="<?php echo e(asset($p->kwitansi)); ?>" class="btn btn-success mt-2" target="_blank">
                                        Unduh Kwitansi
                                    </a>
                                <?php endif; ?>
                        </td>
                    </tr>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal-<?php echo e($p->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tolak Pembayaran</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                                <div class="modal-body">
                                    <form action="/app/daftar-pembayaran/tolak/<?php echo e($p->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <label for="">Alasan Ditolak</label>
                                        <input type="text" class="form-control" name="status_info">
                                        <button class="btn btn-danger mt-2">Tolak Pembayaran</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app/_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/daftar_pembayaran.blade.php ENDPATH**/ ?>
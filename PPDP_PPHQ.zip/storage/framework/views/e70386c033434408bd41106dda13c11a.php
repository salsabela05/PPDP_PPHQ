
<?php $__env->startSection('konten'); ?>

<div class="container">
    <h4>Daftar Pembagian Kelas</h4>
    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama_kelas => $daftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <?php echo e($nama_kelas); ?>

                <a href="<?php echo e(route('sekretaris.kelas.cetak', $nama_kelas)); ?>" class="btn btn-light btn-sm float-right">Cetak Absensi</a>
            </div>
            <div class="card-body">
                <ul>
                    <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($santri->nama); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/sekretaris/kelas.blade.php ENDPATH**/ ?>
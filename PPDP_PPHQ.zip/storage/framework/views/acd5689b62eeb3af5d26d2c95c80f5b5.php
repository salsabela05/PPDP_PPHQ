<!DOCTYPE html>
<html>
<head>
    <title>Absensi Kelas <?php echo e($jenjang); ?></title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
    </style>
</head>
<body>
    <h2>Absensi Santri - Kelas <?php echo e($jenjang); ?></h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenjang</th>
                <th>TTD</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($s->nama); ?></td>
                <td><?php echo e($s->jenjang); ?></td>
                <td></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/sekretaris/absensi.blade.php ENDPATH**/ ?>
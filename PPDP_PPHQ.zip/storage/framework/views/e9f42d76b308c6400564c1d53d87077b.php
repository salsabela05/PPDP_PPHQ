
<?php $__env->startSection("konten"); ?>

<div class="container">
    <h3 class="my-4">Daftar Formulir Calon Santri</h3>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Asal Sekolah</th>
                <th>No HP Santri</th>
                <th>Link Berkas</th>
                <th>Surat Perjanjian</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($f->nama); ?></td>
                <td><?php echo e($f->asal_sekolah); ?></td>
                <td><?php echo e($f->nohp_santri); ?></td>
                <td>
                    <?php if($f->link_berkas): ?>
                        <a href="<?php echo e($f->link_berkas); ?>" target="_blank" class="btn btn-sm btn-success">Lihat Berkas</a>
                    <?php else: ?>
                        <span class="text-danger">Belum diisi</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($f->surat_perjanjian): ?>
                        <a href="<?php echo e(asset('storage/' . $f->surat_perjanjian)); ?>" target="_blank" class="btn btn-sm btn-primary">Lihat</a>
                    <?php else: ?>
                        <span class="text-muted">Belum diunggah</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($f->status_formulir ?? 'Belum diverifikasi'); ?>

                    <?php if($f->status_info): ?>
                        <br><small class="text-danger"><?php echo e($f->status_info); ?></small>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('formulir.verifikasi', ['id' => $f->id, 'status' => 'diterima'])); ?>" method="GET">
                        <button class="btn btn-sm btn-success mb-1">Terima</button>
                    </form>

                    <!-- Tombol buka modal tolak -->
                    <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modalTolak-<?php echo e($f->id); ?>">
                        Tolak
                    </button>

                    <!-- Modal tolak -->
                    <div class="modal fade" id="modalTolak-<?php echo e($f->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="/admin/formulir/tolak/<?php echo e($f->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title">Tolak Formulir</h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <label>Alasan Penolakan</label>
                                        <input type="text" name="status_info" class="form-control" required>
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-danger">Tolak</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("app/_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/daftar_formulir.blade.php ENDPATH**/ ?>
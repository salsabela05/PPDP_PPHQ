<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #f0f0f0; }
        .ttd-container { margin-top: 50px; width: 100%; display: flex; justify-content: space-between; }
        .ttd { text-align: center; width: 200px; float: right; }
    </style>
</head>
<body>
    <h3 align="center">Laporan Data Santri</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Tempat, Tgl Lahir</th>
                <th>JK</th>
                <th>Alamat</th>
                <th>Nama Wali</th>
                <th>Tahun Masuk</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index+1); ?></td>
                    <td><?php echo e($p->formulir->nama); ?></td>
                    <td><?php echo e($p->formulir->nik); ?></td>
                    <td><?php echo e($p->formulir->tempat_lahir); ?></td>
                    <td><?php echo e($p->formulir->jenis_kelamin); ?></td>
                    <td><?php echo e($p->formulir->alamat); ?></td>
                    <td><?php echo e($p->formulir->nama_wali); ?></td>
                    <td><?php echo e(date('Y', strtotime($p->formulir->created_at))); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="ttd-container">
        <div class="ttd">
            <p>Metro, <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?></p>
            <br><br><br>
            <p>Pondok Pesantren Hidayatul Qur'an</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/laporan_pdf.blade.php ENDPATH**/ ?>
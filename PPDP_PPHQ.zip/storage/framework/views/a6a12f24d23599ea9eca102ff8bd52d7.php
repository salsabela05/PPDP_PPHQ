<?php $__env->startSection("konten"); ?>

<div class="card">
    <div class="card-body">
        <h3>Upload Bukti Pembayaran</h3>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="/app/pembayaran/submit" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-2">
                <label>Bukti Pembayaran</label>
                <input type="file" name="bukti_pembayaran" class="form-control" required>
            </div>
            <div class="mb-2">
                <label>Keterangan</label>
                <input type="text" name="keterangan" class="form-control" required>
            </div>
            <button class="btn btn-primary mb-0">Upload</button>
        </form>

        <h3 class="mt-4">Riwayat Pembayaran</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Keterangan</th>
                    <th>Bukti</th>
                    <th>Status</th>
                    <th>Kwitansi</th> 
                </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->keterangan); ?></td>
                        <td><a href="<?php echo e(asset('storage/' . $p->bukti)); ?>" target="_blank">Lihat Bukti</a></td>
                        <td>
                            <?php echo e($p->status); ?>

                            <?php if($p->status_info): ?>
                                - <?php echo e($p->status_info); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->status == 'dikonfirmasi' && $p->kwitansi): ?>
                                <a href="<?php echo e(asset('storage/' . $p->kwitansi)); ?>" class="btn btn-sm btn-success" target="_blank">
                                    Unduh Kwitansi
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("app/_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/pembayaran.blade.php ENDPATH**/ ?>
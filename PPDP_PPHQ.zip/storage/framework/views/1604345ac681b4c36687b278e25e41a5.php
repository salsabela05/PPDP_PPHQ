<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran</title>
</head>
<body onload="window.print()">
<center>
    
    <h3>laporan Pembayaran</h3>
</center>

<div class="card">
    <div class="card-body">
        <table class="table" width="100%" border="1">
        <thead>
                <tr>
                    <th>No</th>
                    <th>calon santri</th>
                    <th>Keterangan</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->formulir->nama); ?></td>
                        <td><?php echo e($p->keterangan); ?></td>
                        <td><?php echo e($p->created_at); ?></td>
                        <td><?php echo e($p->status); ?></td>   
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html><?php /**PATH D:\Project_Skripsi\PPDP_PPHQ\resources\views/app/cetak_pembayaran.blade.php ENDPATH**/ ?>